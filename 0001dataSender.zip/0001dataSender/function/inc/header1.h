/*
 * header1.h
 *
 *  Created on: 05-Oct-2020
 *      Author: Training
 */

#ifndef INC_HEADER1_H_
#define INC_HEADER1_H_
uint32_t pot();
int pir();
#endif /* INC_HEADER1_H_ */
